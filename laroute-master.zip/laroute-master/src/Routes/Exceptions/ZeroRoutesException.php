<?php

namespace Lord\Laroute\Routes\Exceptions;

class ZeroRoutesException extends \Exception { }
